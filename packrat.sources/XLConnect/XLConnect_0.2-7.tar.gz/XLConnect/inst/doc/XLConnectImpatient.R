### R code from vignette source 'XLConnectImpatient.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: setup
###################################################

	if( !file.exists( 'figs' ) ) dir.create( 'figs' )
	# require(tikzDevice)
	


###################################################
### code chunk number 2: setup
###################################################
	require(XLConnect)


