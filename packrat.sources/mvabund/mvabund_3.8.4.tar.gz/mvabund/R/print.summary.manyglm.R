print.summary.manyglm <- function( x, ... )
{
   default.print.summary.manyglm(x, ...)
   return (invisible())
}
