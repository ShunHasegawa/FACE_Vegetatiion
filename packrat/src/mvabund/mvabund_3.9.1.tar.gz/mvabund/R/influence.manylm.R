influence.manylm <- 
function (model, do.coef = TRUE, ...) 
manylm.influence(model, do.coef = do.coef, ...)
