print.anova.manyglm <- function( x, ... )
{
   default.print.anova.manyglm(x, ...)
   return (invisible())
}
